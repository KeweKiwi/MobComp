//
//  ContentView.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct ContentView: View {
    @StateObject private var store = MovieStore()
    @State private var searchText = ""


    // State untuk Easter Egg
    @State private var isEggUnlocked = false
    @State private var showEggBanner = false


    // Film rahasia
    private let secretMovie = Movie(
        title: "The Secret Reel",
        genre: "Mystery",
        posterURL: "https://picsum.photos/300/400?random=999",
        overview: "Tersimpan diam-diam, menunggu yang penasaran menemukannya.",
        releaseYear: 2023,
        rating: 8.5,
        duration: "2h 10m"
    )


    // Grid
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]


    // Semua film waktu easter egg ke unlock
    private var allMovies: [Movie] {
        isEggUnlocked ? (store.movies + [secretMovie]) : store.movies
    }


    // Filter searc bar
    private var filteredMovies: [Movie] {
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if q.isEmpty { return allMovies }
        return allMovies.filter { m in
            m.title.localizedCaseInsensitiveContains(q) ||
            m.genre.localizedCaseInsensitiveContains(q)
        }
    }


    var body: some View {
        NavigationStack {
            ZStack {
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 12) {
                        ForEach(filteredMovies) { movie in
                            NavigationLink {
                                MovieDetailView(movie: movie)
                            } label: {
                                MovieCard(movie: movie)
                            }
                            // animasi masuk/keluar item di grid
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                    .padding()
                }


                // banner animasi saat egg kebuka
                if showEggBanner {
                    Text("🍿 Easter Egg Unlocked!")
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(.ultraThinMaterial)
                        .clipShape(Capsule())
                        .shadow(radius: 6)
                        .transition(.scale.combined(with: .opacity))
                        .padding(.top, 20)
                        .frame(maxHeight: .infinity, alignment: .top)
                }
            }
            
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Text("UCFlix")
                        .font(.system(size: 50))
                        .font(.title.bold())
                        .foregroundStyle(
                            LinearGradient(colors: [AppTheme.primary, .black.opacity(0.8)],
                                           startPoint: .leading, endPoint: .trailing)
                        )
                        .onLongPressGesture(minimumDuration: 1.0) {
                            // Easter Egg toggle
                            withAnimation(.spring) {
                                                isEggUnlocked.toggle()
                                                showEggBanner = true
                                            }
                        }
                        
                    
                }
            }

            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarBackground(.clear, for: .navigationBar)
        }
        //  Animasi perubahan list saat search / egg on-off
        .animation(.spring(response: 0.5, dampingFraction: 0.85), value: filteredMovies.count)
        .animation(.spring(response: 0.5, dampingFraction: 0.85), value: isEggUnlocked)
        
        .tint(.white)
        .searchable(text: $searchText, prompt: "Cari judul atau genre")
    }
}


#Preview { ContentView() }











