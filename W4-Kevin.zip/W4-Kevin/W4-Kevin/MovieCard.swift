//
//  MovieCard.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieCard: View {
    let movie: Movie
    @State private var appear = false
    @State private var pulse = false


    var isSecret: Bool {
        movie.title == "The Secret Reel"
    }


    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // Poster dari URL (AsyncImage)
            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                if let img = phase.image {
                    img.resizable().scaledToFill()
                } else if phase.error != nil {
                    Color.red.overlay(Image(systemName: "xmark.octagon").font(.largeTitle))
                } else {
                    ProgressView()
                }
            }
            .frame(height: 200)
            .clipped()
            .cornerRadius(16)
        
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(AppTheme.primary.opacity(0.6), lineWidth: 2)
            )
            .shadow(color: AppTheme.primary.opacity(0.3), radius: 8, x: 0, y: 4)



            // ✅ Glow kecil khusus film rahasia (pulsing)
            .shadow(color: isSecret ? .yellow.opacity(pulse ? 0.6 : 0.2) : .black.opacity(0.25),
                    radius: isSecret ? (pulse ? 20 : 8) : 6, x: 0, y: 6)


            // Overlay gradien + teks
            LinearGradient(colors: [.clear, .black.opacity(0.7)],
                           startPoint: .center, endPoint: .bottom)
                .cornerRadius(16)


            VStack(alignment: .leading, spacing: 4) {
                Text(movie.title)
                    .font(.headline)
                    .foregroundColor(.white)
                    .lineLimit(1)
                Text(movie.genre)
                    .font(.caption)
                    .foregroundColor(.white.opacity(0.9))
            }
            .padding()
        }
        // Animasi
        .opacity(appear ? 1 : 0)
        .offset(y: appear ? 0 : 12)
        .onAppear {
            withAnimation(.easeOut(duration: 0.35)) {
                appear = true
            }
            if isSecret {
                withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true)) {
                    pulse = true
                }
            }
        }
    }
}










