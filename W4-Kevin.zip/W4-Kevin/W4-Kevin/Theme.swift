//
//  Theme.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import SwiftUI

enum AppTheme {
    static let primary = Color.orange
    static let background = Color.white  
    static let bgGradient = LinearGradient(
        colors: [background, primary.opacity(0.15)],
        startPoint: .top, endPoint: .bottom
    )
}
