//
//  MovieDetailView.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ZStack {
      
            LinearGradient(
                colors: [AppTheme.primary.opacity(0.8), .white],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    AsyncImage(url: URL(string: movie.posterURL)) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .scaledToFit()
                        } else if phase.error != nil {
                            Color.red
                                .overlay(Image(systemName: "xmark.octagon").font(.largeTitle))
                        } else {
                            ProgressView()
                        }
                    }
                    .cornerRadius(16)
                    
                    Text(movie.title)
                        .font(.title).bold()
                    
                    Text(movie.genre)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    // ⭐️ Info tambahan
                    HStack {
                        Label("\(movie.releaseYear)", systemImage: "calendar")
                        Spacer()
                        HStack(spacing: 4) {
                            Image(systemName: "star.fill")
                                .foregroundColor(.yellow)
                            Text(String(format: "%.1f/10", movie.rating))
                        }
                        Spacer()
                        Label(movie.duration, systemImage: "clock")
                    }
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    
                    Text(movie.overview)
                }
                .padding()
            }
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
        .tint(AppTheme.primary)
    }
}






