import Foundation


struct Movie: Identifiable {
    let id = UUID()
    let title: String
    let genre: String
    let posterURL: String
    let overview: String
    let releaseYear: Int
    let rating: Double
    let duration: String
}


// data
let sampleMovies: [Movie] = [
    Movie(
        title: "Sky Journey",
        genre: "Adventure",
        posterURL: "https://picsum.photos/300/400?random=1",
        overview: "Sebuah perjalanan melintasi awan untuk menemukan rumah.",
        releaseYear: 2023,
        rating: 8.5,
        duration: "2h 10m"
    ),
    Movie(
        title: "City Lights",
        genre: "Drama",
        posterURL: "https://picsum.photos/300/400?random=2",
        overview: "Kisah persahabatan di tengah hiruk pikuk kota.",
        releaseYear: 2021,
        rating: 7.9,
        duration: "1h 45m"
    ),
    Movie(
        title: "Neon Runner",
        genre: "Action",
        posterURL: "https://picsum.photos/300/400?random=3",
        overview: "Pelarian penuh adrenalin di malam bertabur neon.",
        releaseYear: 2022,
        rating: 8.1,
        duration: "2h 00m"
    ),
    Movie(
        title: "Hahahaha",
        genre: "Comedy",
        posterURL: "https://picsum.photos/300/400?random=4",
        overview: "Ketawa trus.",
        releaseYear: 2020,
        rating: 6.5,
        duration: "1h 30m"
    ),
    Movie(
        title: "Class Assignment",
        genre: "Horror",
        posterURL: "https://picsum.photos/300/400?random=5",
        overview: "Lariiiiiii.",
        releaseYear: 2024,
        rating: 7.2,
        duration: "1h 50m"
    )
]







