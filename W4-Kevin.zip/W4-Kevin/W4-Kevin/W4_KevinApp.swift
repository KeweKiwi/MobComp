//
//  W4_KevinApp.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W4_KevinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .tint(.orange)
        }
    }
}
