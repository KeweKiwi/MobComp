//
//  MovieStore.swift
//  W4-Kevin
//
//  Created by student on 02/10/25.
//

import Foundation
import SwiftUI


final class MovieStore: ObservableObject {
    @Published var movies: [Movie] = sampleMovies
}
