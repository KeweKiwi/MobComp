//
//  ContentView.swift
//  TH02-Kevin William Faith
//
//  Created by student on 23/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var tasks: [String] = ["Membeli labubu", "We Go Gym🏋", "Ngoding seru❤️"]
    @State private var newTask: String = ""
    
    var body: some View {
        NavigationView {
            VStack {
                // MARK: - Input Bagian Atas
                HStack {
                    
                    TextField("Masukkan tugas baru...", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading)
                    
                    // Button untuk nambah
                    Button(action: addTask) {
                        Text("ADD")
                            .padding(.horizontal, 15)
                            .padding(.vertical, 8)
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                    .padding(.trailing)
                }
                .padding(.top)
                
                // MARK: - Daftar Tugas
                
                List {
                    ForEach(tasks, id: \.self) { task in
                        Text(task)
                    }
                    .onDelete(perform: deleteTask)	
                }
                .listStyle(InsetGroupedListStyle())
                .navigationTitle("TO-DO LIST⭐️")
                
                // Tambahkan toolbar di sini untuk tombol "Hapus Semua"
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Delete All") {
                            deleteAllTasks()
                        }
                        .foregroundColor(.red)
                        .padding(.horizontal,10)
                        .padding(.vertical,5)
                    }
                }
                
                // MARK: - Label note
                               
                               Text("Note: Swipe left to delete.")
                                   .font(.caption)
                                   .foregroundColor(.secondary)
                                   .padding(.top, 10)
                            
            }
        }
    }
    
    // MARK: - Functions
    
    // Function untuk menambah function ke 
    func addTask() {
        // Pastikan input tidak kosong
        if !newTask.isEmpty {
            tasks.append(newTask)
            newTask = ""
        }
    }
    
    // Function untuk menghapus
    func deleteTask(at offsets: IndexSet) {
        tasks.remove(atOffsets: offsets)
    }
    
    // Function baru untuk menghapus semua tugas
        func deleteAllTasks() {
            tasks.removeAll()
        }
}

#Preview {
    ContentView()
}
