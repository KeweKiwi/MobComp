//
//  TH02_Kevin_William_FaithApp.swift
//  TH02-Kevin William Faith
//
//  Created by student on 23/09/25.
//

import SwiftUI

@main
struct TH02_Kevin_William_FaithApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
