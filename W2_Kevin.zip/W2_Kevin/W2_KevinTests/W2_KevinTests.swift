//
//  W2_KevinTests.swift
//  W2_KevinTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W2_Kevin

struct W2_KevinTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
