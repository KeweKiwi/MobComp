//
//  ContentView.swift
//  W2_Kevin
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    @State private var isOn = false
    @State private var volume: Double = 0.5
    @State private var name: String = ""
    @State private var point: Int = 80
    let fruits = ["Apple", "Banana", "Orange", "Mango"]
    
    
    
    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(title, action: action)
            .padding(.horizontal, 16) .padding(.vertical, 10)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
        
    }
    
    private func progressCard(score: Int) ->
    some View {
        VStack{
            Text("Score: \(score)")
                .font(.headline)
            ProgressView(value: Double(score)/100)
            Text("\(score)/\(100)")
                .foregroundStyle(.secondary)
        }
    }

    var body: some View {
        //       🌏MENCOBA FOR🌏
        
        //        VStack(spacing: 20) {
        //            ForEach(2..<10, id: \.self) {
        //                Text("Hello, World!\($0)")
        //            }
        //        }
        //        .padding()
        //        .background(Color.gray.opacity(0.2))
        
        
        
        //        🌏SPACERRRRRR🌏
        
        //        VStack (spacing: 8){
        //            Text("Kevin")
        //            Spacer()
        //            Text("SBY")
        //            Spacer()
        //            Text("kokokok")
        //
        //        }
        
//        🌏Mencoba🌏
//        ZStack{
//            RoundedRectangle(cornerRadius: 20)
//                .fill(Color.blue)
//                .frame(width: 300, height: 200)
//            
//            
//            Text("Hello, World!")
//                .foregroundColor(.white)
//                .font(.headline)
//            
//            Circle()
//                .frame(width:50, height: 50)
//                .opacity(0.2)
//        }
//        
        
//        🌏EXERCISE 1🌏
//        ZStack{
//            RoundedRectangle(cornerRadius: 20)
//                .fill(.linearGradient(Gradient(colors: [.blue, .red]), startPoint: .leading, endPoint: .trailing))
//                .frame(width: 300, height: 200)
//            HStack{
//                Text("Kevin")
//                    .foregroundColor(.white)
//                    .font(.headline)
//                
//                VStack{
//                    Text("🐔")
//                    HStack{
//                        Text("🍌")
//                        Text("🦴")
//                    }
//                    
//                        
//                }
//            }
//            
//        }
        
//        🌏EXERCISE 2🌏
        
//        ZStack{
//            RoundedRectangle(cornerRadius: 20)
//                .fill(.linearGradient(Gradient(colors: [.purple, .yellow]), startPoint: .leading, endPoint: .trailing))
//                .frame(width: 300, height: 200)
//            HStack{
//                Text("Kevin")
//                    .foregroundColor(.white)
//                    .font(.headline)
//                    .padding(.bottom,130)
//                    .padding(.trailing,102)
//                
//                VStack{
//                    Text("🐔")
//                    HStack{
//                        Text("🍌")
//                        Text("🦴")
//                    }
//                    
//                    
//                        
//                }
//                .padding(.top,100)
//            }
//            
//        }
//        
        
        
        
//        🌏SHADOW🌏
        
//        VStack{
//            Text("Hello, world!")
//                .padding()
//                .background(Color.blue)
//                .cornerRadius(20)
//                .shadow(color: .black, radius: 10, x:2, y:2)
//                .opacity(0.88)
//            
//        }
        
//        🌏BUTTON🌏
        
//        VStack{
//            Button("Tekan Saya >///<"){
//                print("OOPS AKU DIPEGANG >///<")
//            }
//            
//            .foregroundColor(.white)
//            .padding()
//            .background(Color.yellow)
//            .cornerRadius(20)
//            .shadow(color: .black, radius: 10)
//            .opacity(0.88)
//            
//            Button("Tekan Saya >///<"){
//                print("OOPS AKU DIPEGANG >///<")
//            }
//            .buttonStyle(
//                .bordered
//            )
//            .tint(.blue)
//            
//            Button("Tekan Saya >///<"){
//                print("OOPS AKU DIPEGANG >///<")
//            }
//            .padding(.horizontal, 20)
//            .padding(.vertical, 10)
//            .background(.white)
//            .overlay(RoundedRectangle(cornerRadius: 10).stroke(.purple, lineWidth: 2))
//            .foregroundColor(.red)
//        }
        
    //        🌏SYMBOLS🌏
        
//        VStack{
//            Image(systemName:
//            "airpods.gen3")
//            .symbolRenderingMode(.multicolor)
//            .font(.system(size: 100))
//            
//        }
//        
        
        //        🌏TOGGLE, SLIDER, TEXTBOX🌏
            
//            VStack{
//                
//                Toggle("Enable Notificaions", isOn: $isOn)
//                    .padding()
//                Text(isOn ? "Hore" : "Yahh")
//                
//                Slider(value: $volume, in: 0...1)
//                    .padding()
//                Text("Volume Sekarang \(volume)%")
//                
//                TextField("Namamu siapa", text:
//                $name)
//                .textFieldStyle(RoundedBorderTextFieldStyle())
//                .padding()
//                Text("Hello My Name is \(name)")
//                
//                Text(name == "" ? "Nama belum diiisi" : "Hello \(name)")
//                
//            }
        
        
        //        🌏EXERCISE🌏
            
            VStack{
                progressCard(score:point)
                HStack{
                    actionButton("Add 10"){
                        point += 10
                    }
                    actionButton("Reset") { point = 0}
                }
                
            }
        List(fruits, id: \.self) {fruits in
            HStack{
                Text(fruits)
                Spacer()
                Text(" A B C D")
            }
        }
        
    }
}


#Preview {
    ContentView()
}
