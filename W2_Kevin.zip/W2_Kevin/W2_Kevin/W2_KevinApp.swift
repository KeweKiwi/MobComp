//
//  W2_KevinApp.swift
//  W2_Kevin
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W2_KevinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
