//
//  ContentView.swift
//  W01-Kevin
//
//  Created by student on 11/09/25.
//
import SwiftUI


struct ContentView: View {
    var body: some View {
        ZStack{
            Image("background")
            
            VStack {
                            
                Image("mencoba")
                    .resizable()
                    .scaledToFill()
                    .padding()
                    .clipShape(Circle())
                    .frame(width: 300, height: 200)
                    .overlay(Circle().stroke(Color.pink, lineWidth: 10))
                            
                Text("Hi! I'm Kevin")
                    .font(.system(size: 30))
                    .padding()
                    .background(.ultraThinMaterial)
                    .foregroundColor(.yellow)
                
                Text("My age is 20")
                    .font(.system(size: 30))
                    .padding()
                    .background(.ultraThinMaterial)
                    .foregroundStyle(.yellow)
                
                Text("🫀❤️💕")
                    .font(.system(size: 60))
                    .fontWeight(.bold)
                    .padding()
              
            }
        }
       
        .padding()
    }
    let name = "Alice"
    var age = 20
    func greet(){
        print("Hello, \(name), age \(age)")
    }
}
#Preview {
    ContentView()
}
