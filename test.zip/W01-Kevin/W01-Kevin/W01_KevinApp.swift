//
//  W01_KevinApp.swift
//  W01-Kevin
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_KevinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
