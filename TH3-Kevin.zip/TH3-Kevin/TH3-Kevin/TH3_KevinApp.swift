//
//  TH3_KevinApp.swift
//  TH3-Kevin
//
//  Created by student on 01/10/25.
//

import SwiftUI

@main
struct TH3_KevinApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
