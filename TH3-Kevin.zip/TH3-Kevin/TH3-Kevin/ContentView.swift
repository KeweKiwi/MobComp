//
//  ContentView.swift
//  TH3-Kevin
//
//  Created by student on 01/10/25.
//

import SwiftUI


struct HomeView: View {
    let primaryText = Color(red: 0.15, green: 0.15, blue: 0.15)
    let gradientStart = Color(.blue)
    let gradientEnd = Color(red: 0.9, green: 0.26, blue: 0.65)

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(spacing: 24) {
                HeaderView(primaryTextColor: primaryText)
                    .padding(.top, 20)

                SearchBar()

                GoalsCard(gradientStart: gradientStart, gradientEnd: gradientEnd)
                
                MetricsGrid()
            }
            .padding(.horizontal)
        }
        .tabItem {

            Label("Home", systemImage: "house.fill")
        }
    }
}


struct RouteView: View {
    var body: some View {
        Text("Route")
            .font(.largeTitle)
            .tabItem {
                Label("Route", systemImage: "figure.walk")
            }
    }
}

struct StatsView: View {
    var body: some View {
        Text("Activity Statistics & Graphs")
            .font(.largeTitle)
            .tabItem {
                Label("Stats", systemImage: "chart.bar.fill")
            }
    }
}


struct SettingsView: View {
    var body: some View {
        Text("Settings")
            .font(.largeTitle)
            .tabItem {
                Label("Settings", systemImage: "gearshape.fill")
            }
    }
}

// MARK: - Main View

struct ContentView: View {
    var body: some View {
        ZStack {
            
            TabView {
                HomeView()
                RouteView()
                StatsView()
                SettingsView()
            }
            .accentColor(Color(.purple))
        }
    }
}



// MARK: Header View (Top Bar)
struct HeaderView: View {
    let primaryTextColor: Color
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Good Morning,")
                    .font(.subheadline)                    .foregroundColor(.gray)

                Text("Kevin Wow")
                    .font(.system(size: 40))
                    .fontWeight(.bold)
                    .foregroundColor(primaryTextColor)
            }

            Spacer()
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.pink)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.blue, lineWidth: 2))
                .shadow(radius: 5)
        }
    }
}

// MARK: Search Bar
struct SearchBar: View {
    @State private var searchText: String = ""

    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
                .padding(.leading, 8)

            TextField("Search", text: $searchText)
                .padding(.vertical, 12)
        }
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

// MARK: Goals Card
struct GoalsCard: View {
    let gradientStart: Color
    let gradientEnd: Color
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Today's Goal")
                .font(.system(size: 30))
                .fontWeight(.medium)
                .foregroundColor(.white)
                .padding(.top, 30)
            
            HStack {
                GoalTile(
                    iconName: "figure.walk",
                    value: "4 Miles",
                    route: "@Thames Route"
                )
                
                GoalTile(
                    iconName: "figure.open.water.swim",
                    value: "2 Miles",
                    route: "@River Lea"
                )
            }
            .padding(.horizontal, 15)
            .padding(.bottom, 30)
        }
        .frame(maxWidth: .infinity)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [gradientStart, gradientEnd]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .cornerRadius(25)
        .shadow(color: gradientEnd.opacity(0.4), radius: 10, x: 0, y: 10)
    }
}

// MARK: Individual Goal Tile
struct GoalTile: View {
    let iconName: String
    let value: String
    let route: String

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: iconName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 32, height: 32)
                .foregroundColor(.white)
                .padding(.bottom, 5)

            Text(value)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(.white)

            Text(route)
                .font(.caption)
                .foregroundColor(Color.white.opacity(0.8))
        }
        .frame(maxWidth: .infinity, minHeight: 150)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white.opacity(0.2))
                .overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.white.opacity(0.4), lineWidth: 1)
                )
        )
        .cornerRadius(20)
    }
}

// MARK: Metrics Grid (4 bottom)
struct MetricsGrid: View {
    var body: some View {
        VStack(spacing: 10) {
            
            // First row of cards
            HStack(spacing: 16) {
                MetricCard(
                    iconName: "heart.fill",
                    iconColor: .purple,
                    value: "68",
                    unit: "Bpm",
                    primaryTextColor: .black
                )
                
                MetricCard(
                    iconName: "flame.fill",
                    iconColor: .orange,
                    value: "0",
                    unit: "Kcal",
                    primaryTextColor: .black
                )
            }
            // Second row of cards
            HStack(spacing: 16) {
                MetricCard(
                    iconName: "scalemass.fill",
                    iconColor: .teal,
                    value: "73",
                    unit: "Kg",
                    primaryTextColor: .black
                )
                
                MetricCard(
                    iconName: "bed.double.fill",
                    iconColor: .cyan,
                    value: "6.2",
                    unit: "Hr",
                    primaryTextColor: .black
                )
            }
        }
    }
}

// MARK: Individual Metric Card
struct MetricCard: View {
    let iconName: String
    let iconColor: Color
    let value: String
    let unit: String
    let primaryTextColor: Color

    var body: some View {
        VStack(spacing: 3) {
            HStack {
                Image(systemName: iconName)
                    .foregroundColor(iconColor)
                    .font(.title)
                Spacer()
            }
            
                    
            HStack{
                Spacer()
                VStack(alignment: .trailing) {
                    Text(value)
                        .font(.system(size: 30))
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(primaryTextColor)
                    
                    Text(unit)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(15)
        .frame(height: 120) 
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
