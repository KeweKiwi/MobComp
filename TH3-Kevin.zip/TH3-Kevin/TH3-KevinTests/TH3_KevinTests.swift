//
//  TH3_KevinTests.swift
//  TH3-KevinTests
//
//  Created by student on 01/10/25.
//

import Testing
@testable import TH3_Kevin

struct TH3_KevinTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
